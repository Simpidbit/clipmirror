import sys
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)
FILENAME = './paste'

@app.route('/paste')
def index():
    return render_template('index.html')

@app.route('/paste/update', methods = ['POST'])
def update():
    data = request.get_json()
    with open(FILENAME, 'wt') as f:
        f.write(data['text'])
    return jsonify({'status': 'ok'}), 200

@app.route('/paste/getpaste', methods = ['GET'])
def getpaste():
    text = None
    with open(FILENAME, 'rt') as f:
        text = f.read()
    return jsonify({'text': text}), 200

if __name__ == '__main__':
    app.run(host = '0.0.0.0', port = int(sys.argv[1]), debug = True)
